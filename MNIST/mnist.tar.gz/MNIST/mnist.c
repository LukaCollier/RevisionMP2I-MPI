#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]){
  FILE *f = fopen("/home/florian/MNIST/train-images-idx3-ubyte","r");
  int magic[4];
  fread(magic,4,4,f);
  printf("%x\n",*magic);

  int n = 60000, w=28, h=28;

  unsigned char px;
  for (int i = 0; i < h; i = i + 1) {
    for (int j = 0; j < w; j = j + 1) {
      fscanf(f,"%c",&px);
      printf("%4u",px);
    }
    printf("\n");
  }

  return 0;
}
