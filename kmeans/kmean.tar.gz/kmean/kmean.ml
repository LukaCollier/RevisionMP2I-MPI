open Graphics;;

(* Global variables *)
let go_mode = ref false;;
let points = ref [];;
let k = int_of_string Sys.argv.(1);;

(* Display functions *)
let draw_point c (x,y) =
  set_color c; fill_circle x y 3; set_color black;;
let draw_rep c (x,y) =
  set_color c; fill_rect (x-2) (y-2) 5 5; set_color black;;
let display_points () = List.iter (draw_point black) !points;;
let display_state () = assert false;;

(* k-means step-by-step *)
let init () = assert false;;
let next_step () = assert false;;


(* main *)
let manage_events status =
  if status.keypressed && status.key = 'g' then
    begin
      go_mode := true;
      init ();
      display_state ();
    end
  else if !go_mode && status.button then
    begin
      next_step ();
      display_state ();
    end
  else if status.button then
    begin
      let p = (status.mouse_x, status.mouse_y) in
      points := p::!points;
      draw_point black p;
    end
;;

open_graph "";;
loop_at_exit [Button_down; Key_pressed] manage_events;;
