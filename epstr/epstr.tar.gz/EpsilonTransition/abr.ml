(* Arbres binaires de recherches, utilisés pour représenter des ensembles sans doublons *)
type 'a abr = Empty | Node of ('a abr * 'a * 'a abr)

let leaf x = Node (Empty, x, Empty)

let rec iter (f : 'a -> unit) (a : 'a abr) : unit =
  assert false

let union (a1 : 'a abr) (a2 : 'a abr) : 'a abr =
  (* Ne pas hésiter à ajouter une ou plusieurs fonctions intermédiaires *)
  assert false

let intersection (a1 : 'a abr) (a2 : 'a abr) : 'a abr =
  assert false
